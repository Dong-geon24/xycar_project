#!/usr/bin/env python

import start

start.main()
